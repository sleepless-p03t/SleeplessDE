#!/bin/bash
desktop=$XDG_CURRENT_DESKTOP
desktop=${desktop,,}
if [[ "$desktop" == "gnome" ]]; then
	gsettings set org.gnome.desktop.interface text-scaling-factor 1.0
	gsettings set org.gnome.desktop.interface cursor-theme Adwaita
	after 4s gsettings set org.gnome.desktop.interface cursor-size 20
fi
