const low_rgb = [
	'000000', '800000', '008000', '808000', '000080', '800080', '008080', 'c0c0c0',
	'808080', 'ff0000', '00ff00', 'ffff00', '0000ff', 'ff00ff', '00ffff', 'ffffff'
]

function int_to_hex(num) {
	var hex = num.toString(16);
	if (hex.length % 2) {
		hex = '0' + hex;
	}

	return hex + "";
}

//console.log("sed 's/1b 5b 33 38 3b 35 3b %s 6d/g'", string_to_hex(ansi + ""));

function ansi_rgb(ansi) {
	if (ansi < 0 || ansi > 255) return '#000'
	if (ansi < 16) {
		//console.log("sed 's/\\x1b\[1;35;%dm/%s/g'", ansi, low_rgb[ansi]);
		return low_rgb[ansi];
	}

	if (ansi > 231) {
		const s = (ansi - 232) * 10 + 8
		//return `rgb(${s},${s},${s})`
		//console.log("sed 's/\\x1b\[1;35;%dm/%s%s%s/g'", ansi, int_to_hex(s), int_to_hex(s), int_to_hex(s));
		return int_to_hex(s) + int_to_hex(s) + int_to_hex(s);
	}

	const n = ansi - 16
	let b = n % 6
	let g = (n - b) / 6 % 6
	let r = (n - b - g * 6) / 36 % 6
	b = b ? b * 40 + 55 : 0
	r = r ? r * 40 + 55 : 0
	g = g ? g * 40 + 55 : 0

	//return `rgb(${r},${g},${b})`
	// console.log("sed 's/\\x1b\\[1;35;%dm/%s%s%s/g'", ansi, int_to_hex(r), int_to_hex(g), int_to_hex(b));

	return int_to_hex(r) + int_to_hex(g) + int_to_hex(b);
}

var i;

for (i = 0; i < 255; i++) {
	var a = i + "";
	if (a.length == 1) {
		a = "00" + a;
	} else if (a.length == 2) {
		a = "0" + a;
	}

	console.log("sed -i 's/%%%%38;5;%sm/\\$\\{color %s\\}/g' ~/.conky/apps/weather.out", a, ansi_rgb(i));
}
console.log("sed -i 's/%%0m/\\$\\{color\\}/g' ~/.conky/apps/weather.out");
console.log("sed -i 's/%%1m//g' ~/.conky/apps/weather.out");
