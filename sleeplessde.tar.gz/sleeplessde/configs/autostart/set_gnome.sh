#!/bin/bash

# This assumes that gnome is the default desktop
# Edit this as necessary

# this script sets default desktop interface settings for text scaling, cursor theme, and cursor size

desktop=$XDG_CURRENT_DESKTOP
desktop=${desktop,,}
if [[ "$desktop" == "gnome" ]]; then
	gsettings set org.gnome.desktop.interface text-scaling-factor 1.0
	gsettings set org.gnome.desktop.interface cursor-theme Adwaita
	after 4s gsettings set org.gnome.desktop.interface cursor-size 20
fi
