#!/bin/bash

# Here's where everything is going
# The first group is given executable permissions

# autostart/set_gnome.sh			-> $HOME/.config/autostart
# .conky/showterm					-> $HOME/.conky
# .conky/workspacer					-> $HOME/.conky
# .conky/apps/weather.sh			-> $HOME/.conky
# extensions/after					-> /bin
# extensions/chromiumb				-> /usr/local/bin
# i3/i3browser						-> $HOME/.config/i3
# i3/i3shutdown						-> $HOME/.config/i3
# i3/i3toggle						-> $HOME/.config/i3
# i3/sww							-> $HOME/.config/i3
# sleeplessde/sleeplessde			-> /usr/local/bin
#-------------------------------------------------------
# autostart/setgnome.desktop		-> $HOME/.config/autostart
# bkg/kali.png						-> $HOME/Pictures
# .conky/*							-> $HOME/.conky
# .conkyrc							-> $HOME
# i3/config							-> $HOME/.config/i3
# sleeplessde/sleeplessde.desktop	-> /usr/share/xsessions
# xconf/.Xresources					-> $HOME
# cursors/*.tar.gz					-> /usr/share/icons

# Note: the cursors are copied only

# set file permissions as necessary and copy/link files
function moveto
{
	local fp="$1"
	local dp="$2"
	local df="$3"
	local lt=$4

	if [[ "$(head -n 1 $fp)" == "#!/bin/"* ]]; then
		echo "chmod +x $fp"
		chmod +x $fp
	fi
	
	if [ $lt -eq 1 ]; then
		echo "cp $fp $dp"
		cp $fp $dp
	elif [ $lt -eq 2 ]; then
		echo "ln $fp $dp$df"
		ln $fp $dp$df
	elif [ $lt -eq 3 ]; then
		echo "ln -s $fp $dp$df"
		ln -s $fp $dp$df
	fi
}

echo "Initializing installer"
de="$DESKTOP_SESSION"

echo "Detected $de as current desktop environment"
echo "Checking dependencies:"

success=1
missing=()
while read -r line; do
	st=2
	# 2: dpkg error
	while [ $st -eq 2 ]; do
		dpkg -s $line &> /dev/null
		st=$?
		# 0: found
		if [ $st -eq 0 ]; then
			echo -e "[\e[1;37m✔\e[0m] $line"
		# 1: not found
		elif [ $st -eq 1 ]; then
			success=0
			echo -e "[\e[1;31m✖\e[0m] \e[1;31m$line\e[0m"
			missing+=( $line )
		fi
	done
# this list includes the dependencies for i3-gaps
done< <(cat<<EOF
xcompmgr
feh
aterm
wmctrl
xdotool
conky-all
curl
gnome-terminal
libglib2.0-bin
gnome-settings-daemon
nautilus
jq
chromium
libxcb1-dev
libxcb-keysyms1-dev
libpango1.0-dev
libxcb-util0-dev
libxcb-icccm4-dev
libyajl-dev
libstartup-notification0-dev
libxcb-randr0-dev
libev-dev
libxcb-cursor-dev
libxcb-xinerama0-dev
libxcb-xkb-dev
libxkbcommon-dev
libxkbcommon-x11-dev
xutils-dev
autoconf
EOF
)

if [ $success -eq 0 ]; then
	echo "Missing the following dependencies:"
	for d in ${missing[@]}; do
		echo "- $d"
	done

	lst=""
	for d in ${missing[@]}; do
		lst="$lst $d"
	done

	echo "You can install them with sudo apt-get install$lst"
	echo -e "\e[0;31mAborting the install\e[0m"
	exit 1
fi

read -r -p "Is i3-gaps installed? [Y/n]: " isld
if [[ $isld == "Y" ]] || [[ $isld == "y" ]]; then
	echo "Installing SleeplessDE"
else
	echo "Please install i3-gaps and then run this installer again"
	exit 2
fi

echo -en "\e[1;37m"
cat<<EOF
The configs included in this installer contain optimized DPI settings a HP Spectre x360
Please read install.notes for specifications and edit flagged files as necessary
EOF
echo -e "\e[0m\nPlease select an install type:\n"
echo "1: Copy"
echo "2: Hard link"
echo "3: Soft link"
echo
lnk=1
read -r -p "Selection (default is 1): " sel
if [[ "$sel" == "1" ]]; then
	lnk=1
elif [[ "$sel" == "2" ]]; then
	lnk=2
elif [[ "$sel" == "3" ]]; then
	lnk=3
else
	lnk=1
fi

echo
if [ $lnk -eq 1 ]; then
	echo "Starting copy install"
elif [ $lnk -eq 2 ]; then
	echo "Starting hard link install"
elif [ $lnk -eq 3 ]; then
	echo "Starting soft link install"
fi
echo

# creates necessary directories
cd configs
while read -r cdir; do 
	if [[ "$cdir" == ".conky"* ]]; then
		echo "mkdir -p $HOME/$cdir"
		mkdir -p $HOME/$cdir
	elif [[ "$cdir" == "i3"* ]]; then
		echo "mkdir -p $HOME/.config/$cdir"
		mkdir -p $HOME/.config/$cdir
	elif [[ "$cdir" == "autostart"* ]]; then
		echo "mkdir -p $HOME/.config/autostart"
		mkdir -p $HOME/.config/autostart
	fi
done< <(find . -type d | sed 's|^./||' | sed -n '1!p')

echo

# copies/links config files to necessary dirs
while read -r cfile; do
	f=`awk -F'/' '{ print $NF}' <<< $cfile`
	d=`echo $cfile | awk -F'/' '{ $NF=""; print }' | awk '{ gsub(" ", "/"); print }'`
	if [[ "$cfile" == ".conky"* ]]; then
		moveto "$cfile" "$HOME/$d" "$f" $lnk
	elif [[ "$cfile" == "autostart"* ]]; then
		moveto "$cfile" "$HOME/.config/autostart/" "$f" $lnk
	elif [[ "$cfile" == "i3"* ]]; then
		moveto "$cfile" "$HOME/.config/i3/" "$f" $lnk
	elif [[ "$cfile" == "extensions"* ]]; then
		if [[ "$f" == "after" ]]; then
			moveto "$cfile" "/bin/" "$f" $lnk
		else
			moveto "$cfile" "/usr/local/bin/" "$f" $lnk
		fi
	elif [[ "$cfile" == "bkg"* ]]; then
		moveto "$cfile" "$HOME/Pictures/" "$f" $lnk
	elif [[ "$cfile" == "sleeplessde"* ]]; then
		if [[ "$f" == "sleepless.desktop" ]]; then
			moveto "$cfile" "/usr/share/xsessions/" "$f" $lnk
		elif [[ "$f" == "sleepless" ]]; then
			moveto "$cfile" "/usr/local/bin/" "$f" $lnk
		fi
	elif [[ "$cfile" == "xconf"* ]]; then
		if [[ "$f" == ".Xresources" ]]; then
			if [ -f $HOME/.Xresources ]; then
				echo "$HOME/.Xresources already exists"
				cp $cfile $cfile.sde
				moveto "$cfile.sde" "$HOME/" "$f.sde" $lnk
				echo "SleeplessDE .Xresource file is located at $HOME/$f.sde"
			else
				moveto "$cfile" "$HOME/" "$f" $lnk
			fi
		fi
	elif [[ "$cfile" == "cursors"* ]]; then
		td=`mktemp -d`
		cp cursors/*.gz $td
		pushd $td > /dev/null
		tar -xzf *.gz
		rm *.gz
		while read -r line; do
			if [ ! -d /usr/share/icons/$line ]; then
				echo "mv $line /usr/share/icons/"
				mv $line /usr/share/icons/
			fi
		done< <(ls)
		popd > /dev/null
		rm -rf $td
	fi
done< <(find . -type f | sed 's|^./||')
exit 0
